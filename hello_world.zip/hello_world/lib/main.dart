import 'package:flutter/material.dart';
//The main function of this app is to print "Hello World".
//created by: FERNANDEZ, LUCERO & KALNAIN.
void main() {
  runApp(
    MaterialApp(
      home: Center(
        child: Text('Hello World'),
      ),
    ),
  );
}
